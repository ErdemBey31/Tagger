pip3 install telethon
pip3 install tgcrypto pyrogram 
echo "Kurulum başarılı şimdi çalıştır"