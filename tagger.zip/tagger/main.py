import random
import os, logging, asyncio
from telethon import Button
from telethon import TelegramClient, events
from telethon.tl.types import ChannelParticipantsAdmins
from telethon.events import StopPropagation
from config import   log_grup, startmesaj, qrupstart, sahib, support, noqrup
import random
import asyncio
from telethon import utils
import os, logging, asyncio
from telethon import Button
from telethon import TelegramClient, events
from telethon.tl.types import ChannelParticipantsAdmins
from telethon.events import StopPropagation
from pyrogram import Client 
from pyrogram import filters 
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from random import randint
from time import sleep

USERNAME = "supertaggerbot"

logging.basicConfig(
    level=logging.INFO,
    format='%(name)s - [%(levelname)s] - %(message)s'
)
LOGGER = logging.getLogger(__name__)
api_id = "22414322"
api_hash = "d4ae0d06f838826fbcf1fa2dbe6b8f91"
bot_token = "6666571470:AAHtISkrPt1crcgYgOvQtgLBSIK1ccWJSfk"


client = TelegramClient('client', api_id, api_hash).start(bot_token=bot_token)


anlik_calisan = []
etiket_tagger = [] 



@client.on(events.NewMessage(pattern="^/cancel$"))
async def cancel(event):
  global etiket_tagger
  etiket_tagger.remove(event.chat_id)

reklamlar = ['Satın alınan reklamlar burada çıkacak',]

@client.on(events.NewMessage(pattern="^/start$"))
async def start(event):
  if event.is_private:
    await event.reply(f"""`{random.choice(reklamlar)}`
  
  **#SUPERTAGGER Ads**""")
    async for usr in client.iter_participants(event.chat_id):
     ad = f"• 𝖬𝖾𝗋𝗁𝖺𝖻𝖺 [{usr.first_name}](tg://user?id={usr.id}) "
     
     
     await client.send_message("@widiwidilohs", f"ℹ️ Birisi Katıldı - \n {ad}")
     return await event.reply(f"{ad} {startmesaj}", buttons=(
                      [
                       Button.url('🎉  Gruba Ekle  🎉', f'https://t.me/{USERNAME}?startgroup=a')],
                      [
                       Button.inline('📚  𝖪𝗈𝗆𝗎𝗍𝗅𝖺𝗋  ', data="komutlar"),
                       Button.url('👨‍💻  Oluşturucu  ', f'https://t.me/{sahib}')],
                       [Button.url('📝  Güncellemeler  ', f'https://t.me/{support}')]
                    ),
                    link_preview=False)


  if event.is_group:
    
    return await client.send_message(event.chat_id, f"{qrupstart}")


@client.on(events.callbackquery.CallbackQuery(data="start"))
async def handler(event):
    async for usr in client.iter_participants(event.chat_id):
     ad = f"• 𝖬𝖾𝗋𝗁𝖺𝖻𝖺 [{usr.first_name}](tg://user?id={usr.id}) "
     await event.edit(f"{ad} {startmesaj}", buttons=(
                      [
                       Button.url('🎉  Gruba Ekle  🎉', f'https://t.me/{USERNAME}?startgroup=a')],
                      [Button.inline("📚  𝖪𝗈𝗆𝗎𝗍𝗅𝖺𝗋  ", data="komutlar"),
                       Button.url('👨‍💻  Oluşturucu  ', f'https://t.me/{sahib}')],
                       [Button.url('📝  Güncellemeler  ', f'https://t.me/{support}')]
                    ),
                    link_preview=False)

@client.on(events.callbackquery.CallbackQuery(data="komutlar"))
async def handler(event):
    await event.edit("""🇹🇷 Tüm Komutlarımın Listesi ;
    
    
 
       » /utag   <  Mesajınız  >
       - Üyeleri 5'li Etiketlerim.
       
       » /tag   <  Mesajınız  >
       - Üyeleri Tek Tek Etiketlerim.
       
       » /atag   <  Mesajınız  >
       - Sadece Yöneticileri Etiketlerim .
    
       » /etag   <  Mesajınız  >
       - Üyeleri Emoji İle Etiketlerim .
       
       » /stag   <  Mesajınız  >
       - Üyeleri Güzel Sözler İle Etiketlerim .
       
       » /cancel =>
       - Etiket İşlemini Durdururum .

       » /htag < Mesajınız >
       - Üyeleri Hayvan İsimleri İle Etiketlerim!
          
    
""", buttons=(
                      [
                      Button.url('📣  Hata Bildirme Grubu  ', f'https://t.me/{support}'),
                      Button.inline('🇹🇷 Diğer Komutlar  ', data='other')
                      ],
                      [
                      Button.inline("<  Geri Dön  >", data="start"),
                      ]
                    ),
                    link_preview=False)

@client.on(events.callbackquery.CallbackQuery(data="other"))
async def handler(event):
   
    await event.edit("""
    
   » /gay =>
   - Kullanıcı Gay Mi Değil Mi Diye Test Edin👬
   
   » /mal =>
   - Üyelerinizin Mallık Seviyesini Ölçün🐄""", buttons=(
                      [
                      Button.inline("<  Klasik Komutlarım  >", data="komutlar"),
                      ],
                      [
                      Button.inline("Ana Menü", data="start"),
                      ]
                    ),
                    link_preview=False)

mal = ['%10','%20','%30','%40','%50','%60','%70','%80','%90','%100','%200x0',]

@client.on(events.NewMessage(pattern="^/mal ?(.*)"))
async def htag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Açıklama Ekleyin!  ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat.id, f"""`{random.choice(reklamlar)}`      **#SUPERTAGGER Ads**""")
    await client.send_message(event.chat_id, "• Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{usr.first_name}](tg://user?id={usr.id}) Adlı Kullanıcıda {random.choice(mal)} Kadar Mallık Tespit Edildi "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""



gay = ['Gay', 'Gay Değil',]
@client.on(events.NewMessage(pattern="^/gay ?(.*)"))
async def htag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Açıklama Ekleyin!  ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat.id, f"""`{random.choice(reklamlar)}`      **#BSTTAGGER Ads**""")
    await client.send_message(event.chat_id, "• Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{usr.first_name}](tg://user?id={usr.id}) Adlı Kullanıcı {random.choice(gay)} "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""


@client.on(events.NewMessage(pattern="^/utag ?(.*)"))
async def mentionall(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Sebep Yaz Ne İçin Etiketleyeceğim?! ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat_id, "✅ Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                      Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{usr.first_name}](tg://user?id={usr.id}) , "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 5:
        await client.send_message(event.chat_id, f"{msg} \n {usrtxt}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""

    


@client.on(events.NewMessage(pattern="^/atag ?(.*)"))
async def mentionalladmin(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Sebep Yaz Ne İçin Etiketleyeceğim?! ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat_id, "✅ Admin Etiketlemesi Başladı . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"• [{usr.first_name}](tg://user?id={usr.id}) "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Adminleri Etiketlemiyorum  . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""

    


@client.on(events.NewMessage(pattern="^/tag ?(.*)"))
async def tektag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Sebep Yaz Ne İçin Etiketleyeceğim?! ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat_id, "✅ Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"• [{usr.first_name}](tg://user?id={usr.id}) "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""

    



anlik_calisan = []

tekli_calisan = []




emoji = " ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 " \
        "😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡  🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 " \
        "😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡  👻 💀 👽 👾 🤖 🎃 😺 😸 😹 " \
        "😻 😼 😽 🙀 😿 😾 ❄️ 🌺 🌨 🌩 ⛈ 🌧 ☁️ ☀️ 🌈 🌪 ✨ 🌟 ☃️ 🪐 🌏 🌙 🌔 🌚 🌝 🕊 🦩 🦦 🌱 🌿 ☘ 🍂 🌹 🥀 🌾 " \
        "🌦 🍃 🎋🦓 🐅 🐈‍⬛ 🐄 🦄 🐇 🐁 🐷 🐶 🙈 🙊 🐻 🐼 🦊 🐮 🐍 🐊 🦨 🦔 🐒 🦣 🦘 🦥 🦦 🦇 🦍 🐥 🐦 🦜 🕊️ 🦤 🦢 " \
        "🦩 🦚 🦃 🐣 🐓 🐬 🦈 🐠 🐳 🦗 🪳 🐝 🐞 🦋 🐟 🕷️ 🛑 🚧 🚨 ⛽ 🛢 ️🧭 ⚓ 🚏 🚇 🚥 🚦 🛴 🦽 🦼 🚲 🛵 🏍️ 🚙 🚗 🚐 🚚 🚛 🚜 🏎️ 🚒 🚑 🚓 🚕 🛺 🚌 🚈 🚝 🚅 🚄 🚂 🚃 📱 ☎️ 📞 📟 📠 🔌 🔋 🖲 ️💽 💾 💿 📀 🖥 ️💻 ⌨️ 🖨️ 🖱 ️💸 💵 💴 💶 💷 💰 🧾 🧱 🏮 🕯 ️🛍️ 🛒 ♉ ♐ ♎ ♦ ️💚 🧡 🟦 🤎 💛 🟪 🆎 🅱️ 🈷️ ✴️ 🔶 🔼 🎦 ☢️ ☣️ ⚠️ 🚸 ⚜️ 🔱 🔰 〽️ 🎼 🎵 🎶 ☑️ ⬆️ ↗️ ➡️ ↘️ ⬇️ ↙️ ⬅️ ↖️ ↕️ ↔️ ↩️ ↪️ ⤴️ ⤵️ 🔃 🔄 🔙 🔛 🔝 🔚🔜🆕🆓🆙 🆗 🆒 🆖 ℹ️ 🅿️ 🈁 🈂️ 🔣 🔤 🔠 🔡 🔢 ⃣ ⃣ ⃣ 🏁 🚩".split(" ")

@client.on(events.NewMessage(pattern="^/etag ?(.*)"))
async def etag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Sebep Yaz Ne İçin Etiketleyeceğim?! ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat_id, "✅ Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{random.choice(emoji)}](tg://user?id={usr.id}) , "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 5:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""

    



soz = (
'ᴜsʟᴜᴘ ᴋᴀʀᴀᴋᴛᴇʀɪᴅɪʀ ʙɪʀ ɪɴsᴀɴɪɴ', 
'ɪʏɪʏɪᴍ ᴅᴇsᴇᴍ ɪɴᴀɴᴀᴄᴀᴋ , ᴏ ᴋᴀᴅᴀʀ ʜᴀʙᴇʀsɪᴢ ʙᴇɴᴅᴇɴ', 
'ᴍᴇsᴀғᴇʟᴇʀ ᴜᴍʀᴜᴍᴅᴀ ᴅᴇɢɪʟ , ɪᴄɪᴍᴅᴇ ᴇɴ ɢᴜᴢᴇʟ ʏᴇʀᴅᴇsɪɴ',
'ʙɪʀ ᴍᴜᴄɪᴢᴇʏᴇ ɪʜᴛɪʏᴀᴄɪᴍ ᴠᴀʀᴅɪ , ʜᴀʏᴀᴛ sᴇɴɪ ᴋᴀʀsɪᴍᴀ ᴄɪᴋᴀʀᴅɪ', 
'ᴏʏʟᴇ ɢᴜᴢᴇʟ ʙᴀᴋᴛɪɴ ᴋɪ , ᴋᴀʟʙɪɴ ᴅᴇ ɢᴜʟᴜsᴜɴ ᴋᴀᴅᴀʀ ɢᴜᴢᴇʟ sᴀɴᴍɪsᴛɪᴍ', 
'ʜᴀʏᴀᴛ ɴᴇ ɢɪᴅᴇɴɪ ɢᴇʀɪ ɢᴇᴛɪʀɪʀ , ɴᴇ ᴅᴇ ᴋᴀʏʙᴇᴛᴛɪɢɪɴ ᴢᴀᴍᴀɴɪ ɢᴇʀɪ ɢᴇᴛɪʀɪʀ', 
'sᴇᴠᴍᴇᴋ ɪᴄɪɴ sᴇʙᴇᴘ ᴀʀᴀᴍᴀᴅɪᴍ , ʙɪʀ ᴛᴇᴋ sᴇsɪ ʏᴇᴛᴛɪ ᴋᴀʟʙɪᴍᴇ', 
'ᴍᴜᴛʟᴜʏᴜɴ ᴀᴍᴀ sᴀᴅᴇᴄᴇ sᴇɴɪɴʟᴇ', 
'ʙᴇɴ ʜᴇᴘ sᴇᴠɪʟᴍᴇᴋ ɪsᴛᴇᴅɪɢɪᴍ ɢɪʙɪ sᴇᴠɪɴᴅɪᴍ', 
'ʙɪʀɪ ᴠᴀʀ ɴᴇ ᴏᴢʟᴇᴍᴇᴋᴛᴇɴ ʏᴏʀᴜʟᴅᴜᴍ ɴᴇ sᴇᴠᴍᴇᴋᴛᴇɴ', 
'ᴄᴏᴋ ᴢᴏʀ ʙᴇ sᴇɴɪ sᴇᴠᴍᴇʏᴇɴ ʙɪʀɪɴᴇ ᴀsɪᴋ ᴏʟᴍᴀᴋ', 
'ᴄᴏᴋ ᴏɴᴇᴍsɪᴢʟɪᴋ ɪsᴇ ʏᴀʀᴀᴍᴀᴅɪ ᴀʀᴛɪᴋ ʙᴏs ᴠᴇʀɪʏᴏʀᴜᴢ', 
'ʜᴇʀᴋᴇsɪɴ ʙɪʀ ɢᴇᴄᴍɪsɪ ᴠᴀʀ , ʙɪʀ ᴅᴇ ᴠᴀᴢɢᴇᴄᴍɪsɪ', 
'ᴀsɪᴋ ᴏʟᴍᴀᴋ ɢᴜᴢᴇʟ ʙɪʀ sᴇʏ ᴀᴍᴀ sᴀᴅᴇᴄᴇ sᴀɴᴀ', 
'ᴀɴʟᴀʏᴀɴ ʏᴏᴋᴛᴜ , sᴜsᴍᴀʏɪ ᴛᴇʀᴄɪʜ ᴇᴛᴛɪᴍ', 
'sᴇɴ ᴄᴏᴋ sᴇᴠ ᴅᴇ ʙɪʀᴀᴋɪᴘ ɢɪᴅᴇɴ ʏᴀʀ ᴜᴛᴀɴsɪɴ', 
'ᴏ ɢɪᴛᴛɪᴋᴛᴇɴ sᴏɴʀᴀ ɢᴇᴄᴇᴍ ɢᴜɴᴅᴜᴢᴇ ʜᴀsʀᴇᴛ ᴋᴀʟᴅɪ', 
'ʜᴇʀ sᴇʏɪɴ ʙɪᴛᴛɪɢɪ ʏᴇʀᴅᴇ ʙᴇɴᴅᴇ ʙɪᴛᴛɪᴍ ᴅᴇɢɪsᴛɪɴ ᴅɪʏᴇɴʟᴇʀɪɴ ᴇsɪʀɪʏɪᴍ', 
'ɢᴜᴠᴇɴᴍᴇᴋ  sᴇᴠᴍᴇᴋᴛᴇɴ ᴅᴀʜᴀ ᴅᴇɢᴇʀʟɪ , ᴢᴀᴍᴀɴʟᴀ ᴀɴʟᴀʀsɪɴ', 
'ɪɴsᴀɴ ʙᴀᴢᴇɴ ʙᴜʏᴜᴋ ʜᴀʏᴀʟʟᴇʀɪɴɪ ᴋᴜᴄᴜᴋ ɪɴsᴀɴʟᴀʀʟᴀ ᴢɪʏᴀɴ ᴇᴅᴇʀ', 
'ᴋɪᴍsᴇ ᴋɪᴍsᴇʏɪ ᴋᴀʏʙᴇᴛᴍᴇᴢ  ɢɪᴅᴇɴ ʙᴀsᴋᴀsɪɴɪ ʙᴜʟᴜʀ , ᴋᴀʟᴀɴ ᴋᴇɴᴅɪɴɪ', 
'ɢᴜᴄʟᴜ ɢᴏʀᴜɴᴇʙɪʟɪʀɪᴍ ᴀᴍᴀ ɪɴᴀɴ ʙᴀɴᴀ ʏᴏʀɢᴜɴᴜᴍ', 
'ᴏᴍʀᴜɴᴜᴢᴜ sᴜsᴛᴜᴋʟᴀʀɪɴɪᴢɪ ᴅᴜʏᴀɴ  ʙɪʀɪʏʟᴇ ɢᴇᴄɪʀɪɴ', 
'ʜᴀʏᴀᴛ ɪʟᴇʀɪʏᴇ ʙᴀᴋɪʟᴀʀᴀᴋ ʏᴀsᴀɴɪʀ ɢᴇʀɪʏᴇ ʙᴀᴋᴀʀᴀᴋ ᴀɴʟᴀsɪʟɪʀ', 
'ᴀʀᴛɪᴋ ʜɪᴄʙɪʀ sᴇʏ ᴇsᴋɪsɪ ɢɪʙɪ ᴅᴇɢɪʟ ʙᴜɴᴀ ʙᴇɴᴅᴇ ᴅᴀʜɪʟɪᴍ', 
'ᴋɪʏᴍᴇᴛ ʙɪʟᴇɴᴇ ɢᴏɴᴜʟᴅᴇ ᴠᴇʀɪʟɪʀ ᴏᴍᴜʀᴅᴇ', 
'ʙɪʀ ᴄɪᴄᴇᴋʟᴇ ɢᴜʟᴇʀ ᴋᴀᴅɪɴ , ʙɪʀ ʟᴀғʟᴀ ʜᴜᴢᴜɴ', 
'ᴋᴀʟʙɪ ɢᴜᴢᴇʟ ᴏʟᴀɴ ɪɴsᴀɴɪɴ ɢᴏᴢᴜɴᴅᴇɴ ʏᴀs ᴇᴋsɪᴋ ᴏʟᴍᴀᴢᴍɪs', 
'ʜᴇʀ sᴇʏɪ ʙɪʟᴇɴ ᴅᴇɢɪʟ ᴋɪʏᴍᴇᴛ ʙɪʟᴇɴ ɪɴsᴀɴʟᴀʀ ᴏʟsᴜɴ ʜᴀʏᴀᴛɪɴɪᴢᴅᴀ', 
'ᴍᴇsᴀғᴇ ɪʏɪᴅɪʀ ɴᴇ ʜᴀᴅᴅɪɴɪ ᴀsᴀɴ ᴏʟᴜʀ , ɴᴇ ᴅᴇ ᴄᴀɴɪɴɪ sɪᴋᴀɴ', 
'ʏᴜʀᴇɢɪᴍɪɴ ᴛᴀᴍ ᴏʀᴛᴀsɪɴᴅᴀ ʙᴜʏᴜᴋ ʙɪʀ ʏᴏʀɢᴜɴʟᴜᴋ ᴠᴀʀ', 
'ᴠᴇʀɪʟᴇɴ ᴅᴇɢᴇʀɪɴ ɴᴀɴᴋᴏʀᴜ ᴏʟᴍᴀʏɪɴ ɢᴇʀɪsɪ ʜᴀʟʟ ᴏʟᴜʀ', 
'ʜᴇᴍ ɢᴜᴄʟᴜ ᴏʟᴜᴘ ʜᴇᴍ ʜᴀssᴀs ᴋᴀʟᴘʟɪ ʙɪʀɪ ᴏʟᴍᴀᴋ ᴄᴏᴋ ᴢᴏʀ', 
'ᴍᴜʜᴛᴀᴄ ᴋᴀʟɪɴ ʏᴜʀᴇɢɪ ɢᴜᴢᴇʟ  ɪɴsᴀɴʟᴀʀᴀ', 
'ɪɴsᴀɴ ᴀɴʟᴀᴅɪɢɪ ᴠᴇ ᴀɴʟᴀsɪʟᴅɪɢɪ ɪɴsᴀɴᴅᴀ ᴄɪᴄᴇᴋ ᴀᴄᴀʀ', 
'ɪsᴛᴇʏᴇɴ ᴅᴀɢʟᴀʀɪ ᴀsᴀʀ ɪsᴛᴇᴍᴇʏᴇɴ ᴛᴜᴍsᴇɢɪ ʙɪʟᴇ ɢᴇᴄᴇᴍᴇᴢ', 
'ɪɴsᴀʟʟᴀʜ sᴀʙɪʀʟᴀ ʙᴇᴋʟᴇᴅɪɢɪɴ sᴇʏ ɪᴄɪɴ ʜᴀʏɪʀʟɪ ʙɪʀ ʜᴀʙᴇʀ ᴀʟɪʀsɪɴ', 
'ɪʏɪ ᴏʟᴀɴ ᴋᴀʏʙᴇᴛsᴇ ᴅᴇ ᴋᴀᴢᴀɴɪʀ', 
'ɢᴏɴʟᴜɴᴜᴢᴇ ᴀʟᴅɪɢɪɴɪᴢ , ɢᴏɴʟᴜɴᴜᴢᴜ ᴀʟᴍᴀʏɪ ʙɪʟsɪɴ', 
'ʏɪɴᴇ ʏɪʀᴛɪᴋ ᴄᴇʙɪᴍᴇ ᴋᴏʏᴍᴜsᴜᴍ ᴜᴍᴜᴅᴜᴍᴜ', 
'ᴏʟᴍᴇᴋ ʙɪʀ sᴇʏ ᴅᴇɢɪʟ ʏᴀsᴀᴍᴀᴋ ᴋᴏʀᴋᴜɴᴄ', 
'ɴᴇ ɪᴄɪᴍᴅᴇᴋɪ sᴏᴋᴀᴋʟᴀʀᴀ sɪɢᴀʙɪʟᴅɪᴍ ɴᴇ ᴅᴇ ᴅɪsᴀʀɪᴅᴀᴋɪ ᴅᴜɴʏᴀʏᴀ', 
'ɪɴsᴀɴ sᴇᴠɪʟᴍᴇᴋᴛᴇɴ ᴄᴏᴋ ᴀɴʟᴀsɪʟᴍᴀʏɪ ɪsᴛɪʏᴏʀᴅᴜ ʙᴇʟᴋɪ ᴅᴇ', 
'ᴇᴋᴍᴇᴋ ᴘᴀʜᴀʟɪ , ᴇᴍᴇᴋ ᴜᴄᴜᴢᴅᴜʀ', 
'gittiğimiz yol yol değil ama, olsun be manzarası çok güzel',
'sᴀᴠᴀsᴍᴀʏɪ ʙɪʀᴀᴋɪʏᴏʀᴜᴍ ʙᴜɴᴜ ᴠᴇᴅᴀ sᴀʏ'
) 


@client.on(events.NewMessage(pattern="^/stag ?(.*)"))
async def stag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Sebep Yaz Ne İçin Etiketleyeceğim?! ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat.id, f"""`{random.choice(reklamlar)}`      **#BSTTAGGER Ads**""")
    await client.send_message(event.chat_id, "• Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{random.choice(soz)}](tg://user?id={usr.id}) "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""

    
hayvan = (
'Köpek 🐕',
'İnek 🐄',
'Kuş',
'Eşek 🐐',
'At',
'Maymun 🐒',
'Keçi 🐏',
'Aslan 🐱',
'Kurbağa 🐸',
'Panda 🦡',
'Zebra 🦓',
'Papağan 🦜',
'Örümcek 🕷️',
'Ahtapus 🐙',
'Fil 🐘',
'Koala 🐨',
'Kan Gururu 🦘',
'Uğur Böceği 🐞',
'Civcic 🐥',
'Osuran Hayvan (Kokarca) 🦨'
)

@client.on(events.NewMessage(pattern="^/htag ?(.*)"))
async def htag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("Eski Mesajları Görmemi TELEGRAM Engelledi ! ")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("• Etiketlemem İçin Geçerli Bir Mesaj Girdiğinden Emin Ol! ")
  else:
    return await event.respond("• Bir Açıklama Ekleyin! Sadece Hayvan İsimleri Yeterli Değil🙃 ")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat.id, f"""`{random.choice(reklamlar)}`      **#SUPERTAGGER Ads**""")
    await client.send_message(event.chat_id, "• Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{random.choice(hayvan)}](tg://user?id={usr.id}) "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum. . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım 📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 1:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""


renk = " 🇿🇼 🇿🇲 🇿🇦 🇾🇹 🇾🇪 🇽🇰 🇼🇸 🇼🇫 🏴󠁧󠁢󠁷󠁬󠁳󠁿 🇻🇺 🇻🇳 🇻🇮 🇻🇬 🇻🇪 🇻🇨 🇻🇦 🇺🇿 🇺🇾 🇺🇸 🇺🇳 🇺🇬 🇺🇦 🇹🇿 🇹🇼 🇹🇻 🇹🇹 🇹🇷 🇹🇴 🇹🇳 🇹🇲 🇹🇱 🇹🇰 🇹🇭 🇹🇫 🇹🇨 🇹🇦 🇸🇿 🇸🇾 🇸🇽 " \
         " 🇸🇻 🇸🇸 🇸🇴 🇸🇲 🇸🇱 🇸🇰 🇸🇮 🇸🇭 🇸🇬 🇸🇪 🇸🇩 🏴󠁧󠁢󠁳󠁣󠁴󠁿 🇸🇦 🇷🇼 🇷🇺 🇷🇸 🇷🇴 🇷🇪 🇶🇦 🇵🇾 🇵🇼 🇵🇹 🇵🇸 🇵🇷 🇵🇳 🇵🇲 🇵🇱 🇵🇰 🇵🇭 🇵🇫 🇵🇪 " \
         " 🇵🇦 🇴🇲 🇳🇿 🇳🇷 🇳🇵 🇳🇴 🇳🇱 🇳🇮 🇳🇬 🇳🇫 🇳🇪 🇳🇨 🇳🇦 🇲🇾 🇲🇽 🇲🇼 🇲🇻 🇲🇹 🇲🇷 🇲🇶 🇲🇵 🇲🇴 🇲🇳 🇲🇰 🇲🇭 🇲🇬 🇲🇪 🇲🇩 🇲🇨 🇲🇦 🇱🇾 🇱🇻 " \
         " 🇱🇺 🇱🇸 🇱🇷 🇱🇰 🇱🇮 🇱🇨 🇱🇧 🇱🇦 🇰🇿 🇰🇾 🇰🇼 🇰🇷 🇰🇵 🇰🇳 🇰🇲 🇰🇮 🇰🇭  🇰🇬 🇰🇪 🇯🇵 🇯🇴 🇯🇲 🇯🇪 🇮🇹 🇮🇸 🇮🇷 🇮🇶 🇮🇴 🇮🇳 🇮🇲 🇮🇱 🇮🇪 " \
         " 🇮🇩 🇮🇨 🇭🇺 🇭🇹 🇭🇷 🇭🇳 🇭🇰 🇬🇺 🇬🇹 🇬🇸 🇬🇷 🇬🇶 🇬🇵 🇬🇲 🇬🇱 🇬🇮 🇬🇬 🇬🇪 🇬🇧 🇬🇦 🇫🇷 🇫🇴 🇫🇲 🇫🇰 🇫🇮 🇪🇺 🇪🇸 🇪🇷 🇪🇭 🇪🇪 " \
         " 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇪🇨 🇩🇿 🇩🇴 🇩🇲 🇩🇰 🇩🇯 🇩🇪 🇨🇿 🇨🇾 🇨🇽 🇨🇼 🇨🇻 🇨🇺 🇨🇷 🇨🇭 🇨🇦 🇦🇿 " .split(" ") 
        

@client.on(events.NewMessage(pattern="^/btag ?(.*)"))
async def rtag(event):
  global etiket_tagger
  if event.is_private:
    return await event.respond(f"{noqrup}")
  
  admins = []
  async for admin in client.iter_participants(event.chat_id, filter=ChannelParticipantsAdmins):
    admins.append(admin.id)
  if not event.sender_id in admins:
    return await event.respond(f"{noadmin}")
  
  if event.pattern_match.group(1):
    mode = "text_on_cmd"
    msg = event.pattern_match.group(1)
  elif event.reply_to_msg_id:
    mode = "text_on_reply"
    msg = event.reply_to_msg_id
    if msg == None:
        return await event.respond("** Eski mesajları göremiyorum !**")
  elif event.pattern_match.group(1) and event.reply_to_msg_id:
    return await event.respond("**• Etiketleme mesajı yazmadın !**")
  else:
    return await event.respond("**• Etiketleme için bir mesaj yazın !**")
    
  if mode == "text_on_cmd":
    await client.send_message(event.chat_id, "✅ Etiketleme İşlemi Başladı. Şimdi Mesajlarımı Bekleyin. . . .",
                    buttons=(
                      [
                       Button.url('📝  Kanalım  📝', f'https://t.me/{support}')
                      ]
                    )
                  ) 
    etiket_tagger.append(event.chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.iter_participants(event.chat_id):
      usrnum += 1
      usrtxt += f"[{random.choice(renk)}](tg://user?id={usr.id}) "
      if event.chat_id not in etiket_tagger:
        await event.respond("⛔ Etiketleme İşlemini Durdurmayı Tercih Ettiğiniz İçin Durdurdum.",
                    buttons=(
                      [
                       Button.url('📝  Kanalım  📝', f'https://t.me/{support}')
                      ]
                    )
                  )
        return
      if usrnum == 5:
        await client.send_message(event.chat_id, f"{usrtxt} \n {msg}")
        await asyncio.sleep(2)
        usrnum = 0
        usrtxt = ""





print(">> Botunuz Aktif<<")
client.run_until_disconnected()
run_until_disconnected()
