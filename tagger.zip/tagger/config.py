
noqrup = "Burası Bir Özel Sohbet Olduğundan Etiketleyemem."
USERNAME = "supertaggerbot"
log_grup = "31"
startmesaj = "\n\n• Grubundaki Neredeyse Tüm Üyeleri Etiketleyebilirim . . . • Beni Nasıl Kullanacağını Bilmiyorsan Altta Komutlar Tuşu Var . . ."
qrupstart = "• Şuan Hizmet Vermeye Hazırım . . .\n\n• Benim Komutlarım Sadece Özelde. . ."
support = "erd3mbey"
sahib = "erd3mbey"
